package com.example.springboot1.repository;

import com.example.springboot1.pojo.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository //spring bean
public interface UserRepository extends CrudRepository<User, Integer> {
}
