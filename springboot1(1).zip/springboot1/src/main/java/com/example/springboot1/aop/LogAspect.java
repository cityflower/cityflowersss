package com.example.springboot1.aop;

import cn.hutool.json.JSONUtil;
import com.example.springboot1.pojo.Log;
import com.example.springboot1.pojo.dto.UserDto;
import com.example.springboot1.repository.LogRepository;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import java.util.Objects;

@Slf4j
@Aspect
@Component
public class LogAspect {

    @Autowired
    private LogRepository logRepository;

    /**
     * 切入点：针对所有控制器方法
     */
    @Pointcut("execution(* com.example.springboot1.controller.*.*(..))")
    public void controllerPointcut() {
    }

    /**
     * 记录请求和响应日志的切面
     *
     * @param joinPoint
     * @return
     * @throws Throwable
     */
    @Around("controllerPointcut()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        Object result = null;
        boolean isSuccess = true; // 标记请求是否成功
        String errorMessage = null; // 记录错误信息
        long startTime = System.currentTimeMillis();

        try {
            result = joinPoint.proceed(args);
        } catch (Exception e) {
            isSuccess = false;
            errorMessage = e.getMessage();
            log.error("请求处理失败，异常信息为: {}", e.getMessage(), e);
            throw e; // 重新抛出异常
        } finally {
            long endTime = System.currentTimeMillis();
            long time = endTime - startTime;
            addLog(joinPoint, result, time, isSuccess, errorMessage);
        }
        return result;
    }

    /**
     * 日志记录入库操作
     */
    public void addLog(JoinPoint joinPoint, Object result, long time, boolean isSuccess, String errorMessage) {
        HttpServletRequest request = ((ServletRequestAttributes)
                Objects.requireNonNull(RequestContextHolder.getRequestAttributes())).getRequest();

        Log logEntity = new Log();
        logEntity.setRequestUrl(request.getRequestURI());
        logEntity.setRequestMethod(request.getMethod());
        logEntity.setMethodName(joinPoint.getSignature().getName());
        logEntity.setMethodParams(extractUserId(joinPoint.getArgs(), request.getMethod())); // 提取 user 的 id
        logEntity.setResponseBody(isSuccess ? JSONUtil.toJsonStr(result) : errorMessage);
        logEntity.setTimeTaken(time);
        logEntity.setOperator("admin"); // 这里可以根据实际情况获取操作人员信息
        logEntity.setIpAddress(getClientIp(request));

        logRepository.save(logEntity);

        log.info("\n\r=======================================\n\r" +
                        "请求地址:{} \n\r" +
                        "请求方式:{} \n\r" +
                        "请求类方法:{} \n\r" +
                        "请求方法参数:{} \n\r" +
                        "返回报文:{} \n\r" +
                        "处理耗时:{} ms \n\r" +
                        "请求状态:{} \n\r" +
                        "错误信息:{} \n\r" +
                        "=======================================\n\r",
                request.getRequestURI(),
                request.getMethod(),
                joinPoint.getSignature(),
                logEntity.getMethodParams(),
                isSuccess ? JSONUtil.toJsonStr(result) : errorMessage,
                String.valueOf(time),
                isSuccess ? "成功" : "失败",
                errorMessage
        );
    }

    /**
     * 提取 user 的 id
     */
    private String extractUserId(Object[] args, String requestMethod) {
        if (args == null || args.length == 0) {
            return null;
        }

        // 根据请求方法提取 user 的 id
        switch (requestMethod) {
            case "POST":
            case "PUT":
                // 假设参数是 UserDto 类型
                if (args[0] instanceof UserDto) {
                    UserDto userDto = (UserDto) args[0];
                    return String.valueOf(userDto.getUserId());
                }
                break;
            case "DELETE":
            case "GET":
                // 假设参数是 userId
                if (args[0] instanceof Integer) {
                    return String.valueOf(args[0]);
                }
                break;
            default:
                return null;
        }
        return null;
    }

    /**
     * 获取客户端 IP 地址
     */
    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_CLIENT_IP");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("HTTP_X_FORWARDED_FOR");
        }
        if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        // 如果 X-Forwarded-For 包含多个 IP，取第一个
        if (ip != null && ip.contains(",")) {
            ip = ip.split(",")[0].trim();
        }
        return ip;
    }
}