package com.example.springboot1.repository;

import com.example.springboot1.pojo.Log;
import org.springframework.data.jpa.repository.JpaRepository;

public interface LogRepository extends JpaRepository<Log, Long> {
}
